// ============================================
// DADOS DOS FILMES E SÉRIES (exemplo)
// ============================================

const moviesData = [
  {
    id: 1,
    title: "Fabiano",
    description: "Peter Parker enfrenta as consequências de revelar sua identidade secreta.",
    image: "https://images.unsplash.com/photo-1635805737707-575885ab0820?w=500&h=750&fit=crop",
    rating: 8.5,
    year: 2021,
    genre: "Ação",
    featured: true,
    video: "https://www.youtube.com/watch?v=g2TXcAAqOv8"
  },
  {
    id: 2,
    title: "The Crown",
    description: "A história épica da Rainha Elizabeth II e sua vida na coroa britânica.",
    image: "https://images.unsplash.com/photo-1598899134739-24c46f58b8c0?w=500&h=750&fit=crop",
    rating: 8.6,
    year: 2016,
    genre: "Drama",
    featured: true
  },
  {
    id: 3,
    title: "Breaking Bad",
    description: "Um professor de química se torna um produtor de metanfetamina para garantir o futuro de sua família.",
    image: "https://images.unsplash.com/photo-1598899134739-24c46f58b8c0?w=500&h=750&fit=crop",
    rating: 9.5,
    year: 2008,
    genre: "Crime",
    featured: true
  },
  {
    id: 4,
    title: "Inception",
    description: "Um ladrão que rouba segredos corporativos através da tecnologia de compartilhamento de sonhos.",
    image: "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=500&h=750&fit=crop",
    rating: 8.8,
    year: 2010,
    genre: "Ficção Científica",
    featured: true
  },
  {
    id: 5,
    title: "The Witcher",
    description: "Um caçador de monstros se envolve em uma trama de magia, destino e poder.",
    image: "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=500&h=750&fit=crop",
    rating: 8.2,
    year: 2019,
    genre: "Fantasia",
    featured: false
  },
  {
    id: 6,
    title: "Peaky Blinders",
    description: "Uma família de gângsteres de Birmingham luta pelo poder após a Primeira Guerra Mundial.",
    image: "https://images.unsplash.com/photo-1598899134739-24c46f58b8c0?w=500&h=750&fit=crop",
    rating: 8.8,
    year: 2013,
    genre: "Crime",
    featured: false
  },
  {
    id: 7,
    title: "The Matrix",
    description: "Um hacker descobre que a realidade é uma simulação e se junta a uma rebelião.",
    image: "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=500&h=750&fit=crop",
    rating: 8.7,
    year: 1999,
    genre: "Ficção Científica",
    featured: false
  },
  {
    id: 8,
    title: "Oppenheimer",
    description: "A história do físico J. Robert Oppenheimer e o desenvolvimento da bomba atômica.",
    image: "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=500&h=750&fit=crop",
    rating: 8.5,
    year: 2023,
    genre: "Drama",
    featured: false
  },
  {
    id: 9,
    title: "Dune",
    description: "Um jovem é enviado a um planeta desértico perigoso em uma missão política e pessoal.",
    image: "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=500&h=750&fit=crop",
    rating: 8.0,
    year: 2021,
    genre: "Ficção Científica",
    featured: false
  },
  {
    id: 10,
    title: "The Office",
    description: "Uma comédia sobre a vida cotidiana em um escritório de uma empresa de papel.",
    image: "https://images.unsplash.com/photo-1598899134739-24c46f58b8c0?w=500&h=750&fit=crop",
    rating: 9.0,
    year: 2005,
    genre: "Comédia",
    featured: false
  }
];

// funcoes de filtro
function getFeaturedMovies() {
  return moviesData.filter(m => m.featured);
}
function getActionMovies() {
  return moviesData.filter(m => m.genre === "Ação");
}
function getComedyMovies() {
  return moviesData.filter(m => m.genre === "Comédia");
}
function getTrendingMovies() {
  return [...moviesData].sort((a,b) => b.rating - a.rating).slice(0, 10);
}
function getRandomMovie() {
  return moviesData[Math.floor(Math.random() * moviesData.length)];
}
function searchMovies(query) {
  return moviesData.filter(movie =>
    (movie.title || '').toLowerCase().includes(query.toLowerCase()) ||
    (movie.description || '').toLowerCase().includes(query.toLowerCase())
  );
}
// hamburger toggle
document.addEventListener('DOMContentLoaded', function(){
  var btn = document.querySelector('.hamburger');
  var nav = document.querySelector('.site-nav');
  if(btn && nav){ btn.addEventListener('click', function(){ nav.classList.toggle('show'); }); }
});
