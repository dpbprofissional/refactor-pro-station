// --- IMPORTAR SUPABASE VIA ESM ---
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"

// --- INICIALIZAÇÃO SUPABASE ---
const SUPABASE_URL = "https://spsqbinemnzcwibnpefp.supabase.co"
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNwc3FiaW5lbW56Y3dpYm5wZWZwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjEyNzYwNjIsImV4cCI6MjA3Njg1MjA2Mn0.GO_7JHRbUBngh6xv_gYDUUpKWNXSW0Z0DhLRcmpnaog"

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY)

// --- ELEMENTOS DO DOM ---
const featuredCarousel = document.getElementById("featuredCarousel")
const trendingCarousel = document.getElementById("trendingCarousel")
const actionCarousel = document.getElementById("actionCarousel")
const comedyCarousel = document.getElementById("comedyCarousel")

const heroTitle = document.getElementById("heroTitle")
const heroDescription = document.getElementById("heroDescription")
const movieModal = document.getElementById("movieModal")
const playerModal = document.getElementById("playerModal")

// --- FUNÇÕES ---

// Buscar todos os filmes do Supabase
async function loadMovies() {
  const { data: movies, error } = await supabase
    .from("movies")
    .select("*")
    .order("id", { ascending: false })

  if (error) {
    console.error("Erro ao carregar filmes:", error)
    return
  }

  displayCarousels(movies)
  displayHero(movies)
}

// Exibir filme em destaque no hero
function displayHero(movies) {
  const featured = movies.find(f => f.featured)
  if (featured) {
    heroTitle.textContent = featured.title
    heroDescription.textContent = featured.description || ""
    document.getElementById("playBtn").onclick = () => openPlayer(featured)
    document.getElementById("infoBtn").onclick = () => openInfoModal(featured)
  }
}

// Criar carrosséis por categoria
function displayCarousels(movies) {
  featuredCarousel.innerHTML = ""
  trendingCarousel.innerHTML = ""
  actionCarousel.innerHTML = ""
  comedyCarousel.innerHTML = ""

  movies.forEach(movie => {
    const card = createMovieCard(movie)

    if (movie.featured) featuredCarousel.appendChild(card)
    if (movie.genre?.toLowerCase() === "ação") actionCarousel.appendChild(card)
    if (movie.genre?.toLowerCase() === "comédia") comedyCarousel.appendChild(card)
    trendingCarousel.appendChild(card)
  })
}

// Criar card de filme
function createMovieCard(movie) {
  const card = document.createElement("div")
  card.classList.add("movie-card")
  card.innerHTML = `
    <img src="${movie.image}" alt="${movie.title}" />
    <h3>${movie.title}</h3>
  `
  card.onclick = () => openInfoModal(movie)
  return card
}

// --- MODAIS ---

function openInfoModal(movie) {
  movieModal.style.display = "block"
  document.getElementById("modalTitle").textContent = movie.title
  document.getElementById("modalDescription").textContent = movie.description || ""
  document.getElementById("modalGenre").textContent = movie.genre || ""
  document.getElementById("modalYear").textContent = movie.year || ""
  document.getElementById("modalRating").textContent = movie.rating != null ? `Nota: ${movie.rating}` : ""
  document.getElementById("modalImage").src = movie.image || ""
}

function openPlayer(movie) {
  playerModal.style.display = "block"
  playerModal.innerHTML = `
    <div class="player-content">
      <span class="close" onclick="playerModal.style.display='none'">&times;</span>
      <iframe width="100%" height="400" src="${movie.video}" frameborder="0" allowfullscreen></iframe>
    </div>
  `
}

// Fechar modais ao clicar no X
document.querySelectorAll(".modal .close").forEach(btn => {
  btn.onclick = e => e.target.closest(".modal").style.display = "none"
})

// --- BUSCA ---
document.getElementById("searchInput").oninput = e => {
  const query = e.target.value.toLowerCase()
  const cards = document.querySelectorAll(".movie-card")
  cards.forEach(card => {
    const title = card.querySelector("h3").textContent.toLowerCase()
    card.style.display = title.includes(query) ? "block" : "none"
  })
}

// --- INICIALIZAÇÃO ---
loadMovies()
// hamburger toggle
document.addEventListener('DOMContentLoaded', function(){
  var btn = document.querySelector('.hamburger');
  var nav = document.querySelector('.site-nav');
  if(btn && nav){ btn.addEventListener('click', function(){ nav.classList.toggle('show'); }); }
});
