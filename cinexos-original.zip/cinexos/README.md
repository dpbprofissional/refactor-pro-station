# Netflix Clone - HTML, CSS e JavaScript Puro

Um clone da interface da Netflix desenvolvido com **HTML, CSS e JavaScript puro**, sem uso de frameworks ou bibliotecas externas.

## 📋 Características

- ✅ Interface responsiva (mobile, tablet, desktop)
- ✅ Navbar fixa com scroll dinâmico
- ✅ Seção herói com filme aleatório
- ✅ Carrosséis de filmes por categoria
- ✅ Modal com detalhes do filme
- ✅ Busca de filmes em tempo real
- ✅ Navegação entre seções
- ✅ Animações suaves
- ✅ Suporte a teclado (ESC para fechar modal, Ctrl+K para busca)
- ✅ Lazy loading de imagens

## 🗂️ Estrutura de Arquivos

```
netflix-clone-vanilla/
├── index.html          # Arquivo HTML principal
├── css/
│   └── style.css       # Estilos CSS (responsivo)
├── js/
│   ├── data.js         # Dados dos filmes e séries
│   └── app.js          # Lógica principal da aplicação
└── README.md           # Este arquivo
```

## 🚀 Como Usar

### 1. Abrir no Navegador

Simplesmente abra o arquivo `index.html` em um navegador moderno:

```bash
# No Linux/Mac
open index.html

# No Windows
start index.html

# Ou arraste o arquivo para o navegador
```

### 2. Servir Localmente (Recomendado)

Para melhor experiência, use um servidor local:

**Com Python 3:**
```bash
python -m http.server 8000
```

**Com Node.js (http-server):**
```bash
npx http-server
```

**Com PHP:**
```bash
php -S localhost:8000
```

Depois acesse: `http://localhost:8000`

## 🎮 Funcionalidades

### Navegação
- **Navbar**: Clique nos links para navegar entre seções
- **Logo**: Clique em "NETFLIX" para carregar um novo filme herói
- **Busca**: Use a barra de busca para procurar filmes (Ctrl+K)

### Interações
- **Hover nos cards**: Mostra título, rating e botões de ação
- **Clique no card**: Abre modal com detalhes completos
- **Botão Assistir**: Simula a reprodução do filme
- **Botão Info**: Abre o modal com informações

### Atalhos de Teclado
- `Ctrl+K` (ou `Cmd+K`): Focar na busca
- `ESC`: Fechar modal
- `Enter`: Executar busca

## 📱 Responsividade

O projeto é totalmente responsivo com breakpoints em:
- **Desktop**: 1024px+
- **Tablet**: 768px - 1023px
- **Mobile**: Até 767px

## 🎨 Personalização

### Mudar Cores
Edite as variáveis CSS em `css/style.css`:

```css
:root {
    --primary-color: #e50914;      /* Vermelho Netflix */
    --dark-bg: #141414;             /* Fundo escuro */
    --light-text: #ffffff;          /* Texto claro */
    --secondary-text: #808080;      /* Texto secundário */
}
```

### Adicionar Filmes
Edite o array `moviesData` em `js/data.js`:

```javascript
{
    id: 21,
    title: "Seu Filme",
    description: "Descrição do filme",
    image: "URL-da-imagem",
    rating: 8.5,
    year: 2023,
    genre: "Gênero",
    featured: false
}
```

### Mudar Fonte
Adicione uma fonte Google no `index.html`:

```html
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
```

E atualize em `css/style.css`:

```css
body {
    font-family: 'Poppins', sans-serif;
}
```

## 🔧 Compatibilidade

- ✅ Chrome/Edge (últimas versões)
- ✅ Firefox (últimas versões)
- ✅ Safari (últimas versões)
- ✅ Navegadores móveis modernos

## 📝 Notas Importantes

1. **Imagens**: As imagens usam URLs do Unsplash. Para usar imagens locais, substitua as URLs por caminhos locais.

2. **Dados**: Os dados são estáticos em `js/data.js`. Para integrar com uma API real, modifique `app.js`.

3. **Reprodução**: O botão "Assistir" mostra um alerta. Para integrar com um player real, modifique a função `playMovie()`.

4. **Armazenamento**: A "Minha Lista" não persiste dados. Para adicionar persistência, use `localStorage`.

## 🎓 Aprendizados

Este projeto demonstra:
- Manipulação do DOM com JavaScript puro
- CSS Grid e Flexbox
- Event listeners e delegação de eventos
- Funções de filtro e busca
- Responsividade com media queries
- Animações CSS
- Boas práticas de organização de código

## 📄 Licença

Livre para usar e modificar.

## 🤝 Contribuições

Sinta-se livre para melhorar este projeto!

---

**Desenvolvido com ❤️ usando apenas HTML, CSS e JavaScript**

