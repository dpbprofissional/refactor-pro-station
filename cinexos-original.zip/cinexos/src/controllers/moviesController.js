// Simulação de um banco em memória (poderia ser um banco real)
let movies = [
  { id: 1, title: "Matrix", year: 1999 },
  { id: 2, title: "Inception", year: 2010 },
  { id: 3, title: "Interstellar", year: 2014 },
];

// 🧾 Listar todos os filmes
export const getAllMovies = (req, res) => {
  try {
    res.status(200).json(movies);
  } catch (error) {
    res.status(500).json({ message: "Erro ao listar filmes.", error: error.message });
  }
};

// ➕ Adicionar novo filme
export const addMovie = (req, res) => {
  try {
    const { title, year } = req.body;

    if (!title || !year) {
      return res.status(400).json({ message: "Envie os campos 'title' e 'year'." });
    }

    const newMovie = {
      id: movies.length > 0 ? movies[movies.length - 1].id + 1 : 1,
      title,
      year,
    };

    movies.push(newMovie);
    res.status(201).json({ message: "Filme adicionado com sucesso!", movie: newMovie });
  } catch (error) {
    res.status(500).json({ message: "Erro ao adicionar filme.", error: error.message });
  }
};

// ✏️ Atualizar um filme existente
export const updateMovie = (req, res) => {
  try {
    const { id } = req.params;
    const { title, year } = req.body;

    const movieIndex = movies.findIndex((m) => m.id === parseInt(id));

    if (movieIndex === -1) {
      return res.status(404).json({ message: "Filme não encontrado." });
    }

    if (!title && !year) {
      return res.status(400).json({ message: "Envie ao menos 'title' ou 'year' para atualizar." });
    }

    movies[movieIndex] = {
      ...movies[movieIndex],
      title: title || movies[movieIndex].title,
      year: year || movies[movieIndex].year,
    };

    res.status(200).json({ message: "Filme atualizado com sucesso!", movie: movies[movieIndex] });
  } catch (error) {
    res.status(500).json({ message: "Erro ao atualizar filme.", error: error.message });
  }
};

// 🗑️ Deletar um filme
export const deleteMovie = (req, res) => {
  try {
    const { id } = req.params;
    const movieIndex = movies.findIndex((m) => m.id === parseInt(id));

    if (movieIndex === -1) {
      return res.status(404).json({ message: "Filme não encontrado." });
    }

    const deletedMovie = movies.splice(movieIndex, 1);

    res.status(200).json({ message: "Filme removido com sucesso!", deleted: deletedMovie[0] });
  } catch (error) {
    res.status(500).json({ message: "Erro ao deletar filme.", error: error.message });
  }
};