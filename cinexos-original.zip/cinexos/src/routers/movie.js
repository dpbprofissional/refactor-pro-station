import express from "express";
import {
  getAllMovies,
  addMovie,
  updateMovie,
  deleteMovie,
} from "../controllers/moviesController.js";

const router = express.Router();

// Rotas principais do CRUD
router.get("/", getAllMovies);     // Listar todos
router.post("/", addMovie);        // Criar
router.put("/:id", updateMovie);   // Atualizar
router.delete("/:id", deleteMovie); // Deletar

export default router;